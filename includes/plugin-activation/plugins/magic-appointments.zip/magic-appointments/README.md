## Magic Appointments Wordpress Plugin

### Description

This plugin provides the appointments custom post type,

TODO:
* Add Calendar shortcode
* Add Appointment creation forms
* ???
