<?php
/**
 * Appointment Post Type Registration
 *
 * @package  Magic_Appointment_Post_Type
 * @license   GPL-2.0+
 */

/**
 * Register post types and taxonomies.
 *
 * @packageMagic_Appointment_Post_Type
 */
class Magic_Appointment_Post_Type_Registrations {

  public $post_type = 'appointment';

  // public $taxonomies = array( 'appointment-category' );

  public function init() {
    // Add the appointment post type and taxonomies
    add_action( 'init', array( $this, 'register' ) );
  }

  /**
   * Initiate registrations of post type and taxonomies.
   *
   * @uses Magic_Appointment_Post_Type_Registrations::register_post_type()
   * @uses Magic_Appointment_Post_Type_Registrations::register_taxonomy_category()
   */
  public function register() {
    $this->register_post_type();
    // $this->register_taxonomy_category();
  }

  /**
   * Register the custom post type.
   *
   * @link http://codex.wordpress.org/Function_Reference/register_post_type
   */
  protected function register_post_type() {
    $labels = array(
      'name'               => __( 'Appointment', 'appointment-post-type' ),
      'singular_name'      => __( 'Appointment', 'appointment-post-type' ),
      'add_new'            => __( 'Add Appointment', 'appointment-post-type' ),
      'add_new_item'       => __( 'Add Appointment', 'appointment-post-type' ),
      'edit_item'          => __( 'Edit Appointment', 'appointment-post-type' ),
      'new_item'           => __( 'New Appointment', 'appointment-post-type' ),
      'view_item'          => __( 'View Appointment', 'appointment-post-type' ),
      'search_items'       => __( 'Search Appointment', 'appointment-post-type' ),
      'not_found'          => __( 'No profiles found', 'appointment-post-type' ),
      'not_found_in_trash' => __( 'No profiles in the trash', 'appointment-post-type' ),
    );

    $supports = array(
      'title',
      'editor',
      'thumbnail',
      'custom-fields',
      'revisions',
    );

    $args = array(
      'labels'          => $labels,
      'supports'        => $supports,
      'capability_type' => 'post',
      'rewrite'         => array( 'slug' => 'appointment', ), // Permalinks format
      'menu_position'   => 30,
      'menu_icon'       => 'dashicons-id',
      'public' => false,  // it's not public, it shouldn't have it's own permalink, and so on
      'publicly_queryable' => true,  // you should be able to query it
      'show_ui' => true,  // you should be able to edit it in wp-admin
      'exclude_from_search' => true,  // you should exclude it from search results
      'show_in_nav_menus' => false,  // you shouldn't be able to add it to menus
      'has_archive' => false,  // it shouldn't have archive page
      'rewrite' => false,  // it shouldn't have rewrite rules
    );

    $args = apply_filters( 'appointment_post_type_args', $args );

    register_post_type( $this->post_type, $args );
  }

  /**
   * Register a taxonomy for Appointment Categories.
   *
   * @link http://codex.wordpress.org/Function_Reference/register_taxonomy
   */
  protected function register_taxonomy_category() {
    $labels = array(
      'name'                       => __( 'Appointment Categories', 'appointment-post-type' ),
      'singular_name'              => __( 'Appointment Category', 'appointment-post-type' ),
      'menu_name'                  => __( 'Appointment Categories', 'appointment-post-type' ),
      'edit_item'                  => __( 'Edit Appointment Category', 'appointment-post-type' ),
      'update_item'                => __( 'Update Appointment Category', 'appointment-post-type' ),
      'add_new_item'               => __( 'Add New Appointment Category', 'appointment-post-type' ),
      'new_item_name'              => __( 'New Appointment Category Name', 'appointment-post-type' ),
      'parent_item'                => __( 'Parent Appointment Category', 'appointment-post-type' ),
      'parent_item_colon'          => __( 'Parent Appointment Category:', 'appointment-post-type' ),
      'all_items'                  => __( 'All Appointment Categories', 'appointment-post-type' ),
      'search_items'               => __( 'Search Appointment Categories', 'appointment-post-type' ),
      'popular_items'              => __( 'Popular Appointment Categories', 'appointment-post-type' ),
      'separate_items_with_commas' => __( 'Separate appointment categories with commas', 'appointment-post-type' ),
      'add_or_remove_items'        => __( 'Add or remove appointment categories', 'appointment-post-type' ),
      'choose_from_most_used'      => __( 'Choose from the most used appointment categories', 'appointment-post-type' ),
      'not_found'                  => __( 'No appointment categories found.', 'appointment-post-type' ),
    );

    $args = array(
      'labels'            => $labels,
      'public'            => true,
      'show_in_nav_menus' => true,
      'show_ui'           => true,
      'show_tagcloud'     => true,
      'hierarchical'      => true,
      'rewrite'           => array( 'slug' => 'appointment-category' ),
      'show_admin_column' => true,
      'query_var'         => true,
    );

    $args = apply_filters( 'appointment_post_type_category_args', $args );
    // register_taxonomy( $this->taxonomies[0], $this->post_type, $args );
  }
}
